# Echo Weaver - Web Deployment Package

This package contains all the necessary files to deploy the Echo Weaver game on PythonAnywhere.

## Files Included

- `app.py`: The main Flask application
- `wsgi.py`: WSGI configuration for PythonAnywhere
- `requirements.txt`: Python dependencies
- `static/`: Static assets (CSS, JavaScript, images)
- `templates/`: HTML templates

## Deployment Instructions

1. Upload this entire package to your PythonAnywhere account
2. Create a new web app using Flask
3. Set the working directory to the location where you uploaded these files
4. Set the WSGI configuration file to point to `wsgi.py`
5. Install dependencies using `pip install -r requirements.txt`
6. Reload the web app

## Game Features

- Defend the core by creating sound waves
- Different wave modes (Normal, Focused, Wide)
- Echo Burst ability to clear nearby enemies
- Fever meter that fills with combos
- Leaderboard to track high scores
- Responsive design for both desktop and mobile devices

## Controls

### Desktop
- Mouse: Click and drag to draw a line, release to unleash a wave
- Keyboard: Press 1, 2, 3 to switch between wave modes
- Keyboard: Press SPACE for Echo Burst

### Mobile
- Touch: Tap and drag to draw a line, release to unleash a wave
- Triple-tap quickly anywhere to cycle wave modes
- Double-tap the core for Echo Burst

## Credits

Echo Weaver - A web-based arcade game
