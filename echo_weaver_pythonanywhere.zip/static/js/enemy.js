// Enemy classes for the game

// Helper function to draw enemy shapes
function drawEnemyShape(ctx, fillColor, outlineColor, radius, lineWidth = 2) {
    // Draw the main body
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fillStyle = fillColor;
    ctx.fill();
    
    // Draw outline
    if (outlineColor) {
        ctx.strokeStyle = outlineColor;
        ctx.lineWidth = lineWidth;
        ctx.stroke();
    }
}

// Base Enemy class
class Enemy {
    constructor() {
        this.radius = SETTINGS.ENEMY_RADIUS;
        this.position = this.getRandomEdgePosition();
        this.color = SETTINGS.ENEMY_COLORS.Enemy;
        this.outlineColor = SETTINGS.WHITE;
        this.pulseTimer = 0;
        this.isBoss = false;
        this.scoreValue = 1;
    }

    getRandomEdgePosition() {
        const edge = Math.floor(Math.random() * 4); // 0: top, 1: right, 2: bottom, 3: left
        let x, y;

        switch (edge) {
            case 0: // top
                x = Math.random() * SETTINGS.WIDTH;
                y = -this.radius;
                break;
            case 1: // right
                x = SETTINGS.WIDTH + this.radius;
                y = Math.random() * SETTINGS.HEIGHT;
                break;
            case 2: // bottom
                x = Math.random() * SETTINGS.WIDTH;
                y = SETTINGS.HEIGHT + this.radius;
                break;
            case 3: // left
                x = -this.radius;
                y = Math.random() * SETTINGS.HEIGHT;
                break;
        }

        return new Vector(x, y);
    }

    update(core, speed, enemyTrails = null) {
        // Move towards the core
        const dirVec = new Vector(
            core.position.x - this.position.x,
            core.position.y - this.position.y
        );
        
        if (dirVec.length() > 0) {
            const normalized = dirVec.normalize();
            this.position = this.position.add(normalized.multiply(speed));
        }

        // Add enemy trail
        if (enemyTrails) {
            enemyTrails.push(new EnemyTrail(this.position, this.color, this.radius / 2));
        }
        
        // Update pulse timer for visual effects
        this.pulseTimer = (this.pulseTimer + 1) % 60;
    }

    draw(ctx) {
        ctx.save();
        ctx.translate(this.position.x, this.position.y);
        
        // Draw pulsating effect for visual interest
        const pulseScale = 1 + 0.1 * Math.sin(this.pulseTimer / 60 * 2 * Math.PI);
        
        drawEnemyShape(ctx, this.color, this.outlineColor, this.radius, 2);
        
        // Draw subtle glow
        ctx.beginPath();
        ctx.arc(0, 0, this.radius * pulseScale * 1.2, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255, 255, 255, ${0.2 + 0.1 * Math.sin(this.pulseTimer / 60 * 2 * Math.PI)})`;
        ctx.lineWidth = 1;
        ctx.stroke();
        
        ctx.restore();
    }

    collidesWith(other) {
        return this.position.distanceTo(other.position) < this.radius + other.radius;
    }
    
    onDestroy() {
        // Chain reaction effect
        if (SETTINGS.CHAIN_REACTION_ENABLED && 
            window.game && 
            window.game.activePowerups && 
            window.game.activePowerups['chain_reaction_active']) {
            
            this.triggerChainReaction();
        }
        
        return this.scoreValue;
    }
    
    triggerChainReaction() {
        if (!window.game) return;
        
        // Find nearby enemies and damage them
        for (let i = 0; i < window.game.enemies.length; i++) {
            const enemy = window.game.enemies[i];
            if (enemy === this) continue;
            
            const distance = this.position.distanceTo(enemy.position);
            if (distance < SETTINGS.CHAIN_REACTION_RADIUS) {
                // Create chain reaction effect
                const effect = new ImpactEffect(
                    this.position,
                    SETTINGS.POWERUP_COLOR_CHAIN_REACTION,
                    SETTINGS.CHAIN_REACTION_RADIUS
                );
                window.game.impactEffects.push(effect);
                
                // Handle enemy defeat
                window.game.enemies.splice(i, 1);
                window.game._handleEnemyDefeat(enemy);
                i--; // Adjust index since we removed an element
            }
        }
    }
}

// ZigzagEnemy class - moves in a zigzag pattern
class ZigzagEnemy extends Enemy {
    constructor() {
        super();
        this.color = SETTINGS.ENEMY_COLORS.ZigzagEnemy;
        this.zigzagTimer = 0;
        this.zigzagFrequency = 30;
        this.zigzagAmplitude = 5;
        this.scoreValue = 2;
    }

    update(core, speed, enemyTrails = null) {
        // Move towards the core with zigzag motion
        const dirVec = new Vector(
            core.position.x - this.position.x,
            core.position.y - this.position.y
        );
        
        if (dirVec.length() > 0) {
            const normalized = dirVec.normalize();
            
            // Add zigzag motion
            this.zigzagTimer++;
            const perpendicularVec = new Vector(-normalized.y, normalized.x);
            const zigzagOffset = perpendicularVec.multiply(
                Math.sin(this.zigzagTimer / this.zigzagFrequency) * this.zigzagAmplitude
            );
            
            const moveVec = normalized.add(zigzagOffset);
            this.position = this.position.add(moveVec.multiply(speed));
        }

        // Add enemy trail
        if (enemyTrails) {
            enemyTrails.push(new EnemyTrail(this.position, this.color, this.radius / 2));
        }
        
        // Update pulse timer for visual effects
        this.pulseTimer = (this.pulseTimer + 1) % 60;
    }
    
    draw(ctx) {
        ctx.save();
        ctx.translate(this.position.x, this.position.y);
        
        // Draw the zigzag enemy
        drawEnemyShape(ctx, this.color, this.outlineColor, this.radius, 2);
        
        // Draw zigzag pattern indicator
        const zigzagSize = this.radius * 0.7;
        ctx.beginPath();
        ctx.moveTo(-zigzagSize, -zigzagSize/2);
        ctx.lineTo(-zigzagSize/2, zigzagSize/2);
        ctx.lineTo(zigzagSize/2, -zigzagSize/2);
        ctx.lineTo(zigzagSize, zigzagSize/2);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        ctx.restore();
    }
}

// GhostEnemy class - requires multiple hits to destroy
class GhostEnemy extends Enemy {
    constructor() {
        super();
        this.color = SETTINGS.ENEMY_COLORS.GhostEnemy;
        this.hitsRemaining = SETTINGS.GHOST_ENEMY_HITS_REQUIRED;
        this.opacity = 0.7;
        this.scoreValue = 3;
    }

    draw(ctx) {
        ctx.save();
        ctx.translate(this.position.x, this.position.y);
        ctx.globalAlpha = this.opacity;
        
        // Draw the ghost enemy with transparency
        drawEnemyShape(ctx, this.color, this.outlineColor, this.radius, 2);
        
        // Draw hit indicator
        for (let i = 0; i < this.hitsRemaining; i++) {
            ctx.beginPath();
            const x = (i - (SETTINGS.GHOST_ENEMY_HITS_REQUIRED - 1) / 2) * 8;
            ctx.arc(x, this.radius / 2, 3, 0, Math.PI * 2);
            ctx.fillStyle = SETTINGS.YELLOW;
            ctx.fill();
        }
        
        // Draw ghost trail effect
        ctx.beginPath();
        ctx.arc(0, 0, this.radius * 1.3, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(150, 150, 255, ${0.3 + 0.2 * Math.sin(this.pulseTimer / 60 * 2 * Math.PI)})`;
        ctx.lineWidth = 2;
        ctx.stroke();
        
        ctx.restore();
    }
    
    update(core, speed, enemyTrails = null) {
        super.update(core, speed * 0.9, enemyTrails); // Ghosts move slightly slower
        
        // Fade in and out
        this.opacity = 0.5 + 0.3 * Math.sin(this.pulseTimer / 60 * 2 * Math.PI);
    }
}

// ChargerEnemy class - charges at the core when close enough
class ChargerEnemy extends Enemy {
    constructor() {
        super();
        this.color = SETTINGS.ENEMY_COLORS.ChargerEnemy;
        this.isCharging = false;
        this.chargeDirection = null;
        this.chargeTimer = 0;
        this.scoreValue = 3;
    }

    update(core, speed, enemyTrails = null) {
        const distToCore = this.position.distanceTo(core.position);
        
        if (!this.isCharging && distToCore < SETTINGS.CHARGER_ENEMY_CHARGE_DISTANCE) {
            // Start charging
            this.isCharging = true;
            this.chargeDirection = new Vector(
                core.position.x - this.position.x,
                core.position.y - this.position.y
            ).normalize();
            this.chargeTimer = 0;
        }
        
        if (this.isCharging) {
            // Continue charging in the same direction
            const chargeSpeed = speed * SETTINGS.CHARGER_ENEMY_CHARGE_SPEED_MULTIPLIER;
            this.position = this.position.add(this.chargeDirection.multiply(chargeSpeed));
            
            // Increment charge timer
            this.chargeTimer++;
            
            // Reset charge after a while
            if (this.chargeTimer > 60) {
                this.isCharging = false;
            }
        } else {
            // Normal movement towards core
            super.update(core, speed, enemyTrails);
        }
        
        // Add enemy trail
        if (enemyTrails) {
            // Add more trails when charging for visual effect
            const trailCount = this.isCharging ? 3 : 1;
            for (let i = 0; i < trailCount; i++) {
                enemyTrails.push(new EnemyTrail(this.position, this.color, this.radius / 2));
            }
        }
    }

    draw(ctx) {
        ctx.save();
        ctx.translate(this.position.x, this.position.y);
        
        // Draw the charger enemy
        drawEnemyShape(ctx, this.color, this.outlineColor, this.radius, 2);
        
        // Draw charging indicator if charging
        if (this.isCharging) {
            ctx.beginPath();
            ctx.arc(0, 0, this.radius * 1.3, 0, Math.PI * 2);
            ctx.strokeStyle = `rgba(255, 100, 0, ${0.5 + 0.5 * Math.sin(Date.now() / 100)})`;
            ctx.lineWidth = 2;
            ctx.stroke();
            
            // Draw directional indicator
            if (this.chargeDirection) {
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.lineTo(
                    this.chargeDirection.x * this.radius * 1.5,
                    this.chargeDirection.y * this.radius * 1.5
                );
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 2;
                ctx.stroke();
            }
        }
        
        ctx.restore();
    }
}

// SplitterEnemy class - splits into smaller enemies when hit
class SplitterEnemy extends Enemy {
    constructor(radius = SETTINGS.ENEMY_RADIUS) {
        super();
        this.radius = radius;
        this.color = SETTINGS.ENEMY_COLORS.SplitterEnemy;
        this.scoreValue = radius === SETTINGS.ENEMY_RADIUS ? 2 : 1;
        this.rotationAngle = 0;
    }

    update(core, speed, enemyTrails = null) {
        super.update(core, speed, enemyTrails);
        
        // Rotate the splitter enemy for visual effect
        this.rotationAngle += 0.05;
    }

    draw(ctx) {
        ctx.save();
        ctx.translate(this.position.x, this.position.y);
        ctx.rotate(this.rotationAngle);
        
        // Draw the splitter enemy
        drawEnemyShape(ctx, this.color, this.outlineColor, this.radius, 2);
        
        // Draw split indicator
        ctx.beginPath();
        ctx.moveTo(-this.radius * 0.7, 0);
        ctx.lineTo(this.radius * 0.7, 0);
        ctx.moveTo(0, -this.radius * 0.7);
        ctx.lineTo(0, this.radius * 0.7);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        ctx.restore();
    }

    split() {
        const newEnemies = [];
        
        if (this.radius * SETTINGS.SPLITTER_ENEMY_RADIUS_MULTIPLIER > 5) {
            for (let i = 0; i < SETTINGS.SPLITTER_ENEMY_COUNT; i++) {
                const newEnemy = new SplitterEnemy(this.radius * SETTINGS.SPLITTER_ENEMY_RADIUS_MULTIPLIER);
                newEnemy.position = new Vector(this.position.x, this.position.y);
                
                // Add slight randomness to position
                const angle = Math.random() * Math.PI * 2;
                const distance = this.radius * 0.5;
                newEnemy.position.x += Math.cos(angle) * distance;
                newEnemy.position.y += Math.sin(angle) * distance;
                
                newEnemies.push(newEnemy);
            }
        }
        
        return newEnemies;
    }
}

// ShieldedEnemy class - has a shield that absorbs hits
class ShieldedEnemy extends Enemy {
    constructor() {
        super();
        this.color = SETTINGS.ENEMY_COLORS.ShieldedEnemy;
        this.shieldHealth = SETTINGS.SHIELDED_ENEMY_SHIELD_HEALTH;
        this.shieldRotation = 0;
        this.scoreValue = 4;
    }

    update(core, speed, enemyTrails = null) {
        super.update(core, speed * 0.8, enemyTrails); // Shielded enemies move slower
        
        // Rotate shield
        this.shieldRotation += 0.02;
    }

    draw(ctx) {
        ctx.save();
        ctx.translate(this.position.x, this.position.y);
        
        // Draw the shielded enemy
        drawEnemyShape(ctx, this.color, this.outlineColor, this.radius, 2);
        
        // Draw shield if it has health
        if (this.shieldHealth > 0) {
            // Rotate shield
            ctx.rotate(this.shieldRotation);
            
            // Draw shield segments
            for (let i = 0; i < this.shieldHealth; i++) {
                const startAngle = (i / this.shieldHealth) * Math.PI * 2;
                const endAngle = ((i + 1) / this.shieldHealth) * Math.PI * 2;
                
                ctx.beginPath();
                ctx.arc(0, 0, this.radius + 5, startAngle, endAngle);
                ctx.strokeStyle = SETTINGS.SHIELDED_ENEMY_SHIELD_COLOR;
                ctx.lineWidth = 3;
                ctx.stroke();
            }
            
            // Draw shield health indicator
            ctx.fillStyle = '#ffffff';
            ctx.font = '10px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(this.shieldHealth, 0, 0);
        }
        
        ctx.restore();
    }
}

// BossEnemy class - powerful enemy with high health that appears every few waves
class BossEnemy extends Enemy {
    constructor() {
        super();
        this.radius = SETTINGS.BOSS_ENEMY_RADIUS;
        this.color = SETTINGS.BOSS_ENEMY_COLOR;
        this.health = SETTINGS.BOSS_ENEMY_HEALTH;
        this.maxHealth = SETTINGS.BOSS_ENEMY_HEALTH;
        this.isBoss = true;
        this.scoreValue = SETTINGS.BOSS_ENEMY_SCORE_MULTIPLIER;
        this.rotationAngle = 0;
        this.outerRotationAngle = 0;
        this.spawnTime = Date.now();
    }
    
    update(core, speed, enemyTrails = null) {
        // Bosses move slower
        super.update(core, speed * SETTINGS.BOSS_ENEMY_SPEED_MULTIPLIER, enemyTrails);
        
        // Update rotation angles
        this.rotationAngle += 0.01;
        this.outerRotationAngle -= 0.005;
        
        // Add more enemy trails for visual effect
        if (enemyTrails) {
            for (let i = 0; i < 3; i++) {
                const angle = Math.random() * Math.PI * 2;
                const distance = this.radius * 0.8;
                const trailPos = new Vector(
                    this.position.x + Math.cos(angle) * distance,
                    this.position.y + Math.sin(angle) * distance
                );
                enemyTrails.push(new EnemyTrail(trailPos, this.color, this.radius / 3));
            }
        }
        
        // Spawn minions periodically
        if (Date.now() - this.spawnTime > 5000 && window.game) { // Every 5 seconds
            this.spawnMinions();
            this.spawnTime = Date.now();
        }
    }
    
    draw(ctx) {
        ctx.save();
        ctx.translate(this.position.x, this.position.y);
        
        // Draw outer glow
        const gradient = ctx.createRadialGradient(
            0, 0, this.radius * 0.8,
            0, 0, this.radius * 1.5
        );
        gradient.addColorStop(0, 'rgba(255, 62, 127, 0.7)');
        gradient.addColorStop(1, 'rgba(255, 62, 127, 0)');
        
        ctx.beginPath();
        ctx.arc(0, 0, this.radius * 1.5, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();
        
        // Draw the boss enemy
        drawEnemyShape(ctx, this.color, this.outlineColor, this.radius, 3);
        
        // Draw inner core
        ctx.beginPath();
        ctx.arc(0, 0, this.radius * 0.6, 0, Math.PI * 2);
        ctx.fillStyle = '#000000';
        ctx.fill();
        
        // Draw rotating inner energy ring
        ctx.rotate(this.rotationAngle);
        
        for (let i = 0; i < 8; i++) {
            const angle = i * (Math.PI / 4);
            const x = this.radius * 0.4 * Math.cos(angle);
            const y = this.radius * 0.4 * Math.sin(angle);
            
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fillStyle = '#ffffff';
            ctx.fill();
        }
        
        // Reset rotation and set up for outer ring
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.translate(this.position.x, this.position.y);
        ctx.rotate(this.outerRotationAngle);
        
        // Draw rotating outer energy ring
        for (let i = 0; i < 12; i++) {
            const angle = i * (Math.PI / 6);
            const x = this.radius * 0.8 * Math.cos(angle);
            const y = this.radius * 0.8 * Math.sin(angle);
            
            ctx.beginPath();
            ctx.arc(x, y, 2, 0, Math.PI * 2);
            ctx.fillStyle = '#ffffff';
            ctx.fill();
        }
        
        // Reset transformation
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.translate(this.position.x, this.position.y);
        
        // Draw health bar
        const healthBarWidth = this.radius * 2;
        const healthBarHeight = 6;
        const healthPercentage = this.health / this.maxHealth;
        
        ctx.fillStyle = '#333333';
        ctx.fillRect(-healthBarWidth / 2, -this.radius - 15, healthBarWidth, healthBarHeight);
        
        ctx.fillStyle = '#ff3e7f';
        ctx.fillRect(
            -healthBarWidth / 2, 
            -this.radius - 15, 
            healthBarWidth * healthPercentage, 
            healthBarHeight
        );
        
        ctx.restore();
    }
    
    spawnMinions() {
        if (!window.game) return;
        
        // Spawn 2-3 minions around the boss
        const minionCount = 2 + Math.floor(Math.random() * 2);
        
        for (let i = 0; i < minionCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const distance = this.radius * 2;
            const position = new Vector(
                this.position.x + Math.cos(angle) * distance,
                this.position.y + Math.sin(angle) * distance
            );
            
            // Create a random minion
            let minion;
            const minionType = Math.random();
            
            if (minionType < 0.4) {
                minion = new Enemy();
            } else if (minionType < 0.7) {
                minion = new ZigzagEnemy();
            } else {
                minion = new GhostEnemy();
            }
            
            minion.position = position;
            window.game.enemies.push(minion);
            
            // Create spawn effect
            window.game.impactEffects.push(new ImpactEffect(position, minion.color));
        }
    }
    
    takeDamage(damage) {
        this.health -= damage;
        return this.health <= 0;
    }
}

class EnemyTrail {
    constructor(x, y, size, color = null) {
        // Handle both position as object and separate x,y coordinates
        if (typeof x === 'object' && x !== null) {
            this.position = new Vector(x.x, x.y);
            this.color = y || '#ff0055';
            this.size = size || 5;
        } else {
            this.position = new Vector(x, y);
            this.color = color || '#ff0055';
            this.size = size || 5;
        }
        this.alpha = 0.5;
    }
    
    update() {
        this.alpha *= SETTINGS.ENEMY_TRAIL_DECAY;
        return this.alpha > 0.01;
    }
    
    draw(ctx) {
        ctx.beginPath();
        ctx.arc(this.position.x, this.position.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${hexToRgb(this.color)}, ${this.alpha})`;
        ctx.fill();
    }
}

// Helper function to convert hex color to rgb for rgba usage
function hexToRgb(hex) {
    // Remove the # if present
    hex = hex.replace(/^#/, '');
    
    // Parse the hex values
    let r, g, b;
    if (hex.length === 3) {
        r = parseInt(hex[0] + hex[0], 16);
        g = parseInt(hex[1] + hex[1], 16);
        b = parseInt(hex[2] + hex[2], 16);
    } else {
        r = parseInt(hex.substring(0, 2), 16);
        g = parseInt(hex.substring(2, 4), 16);
        b = parseInt(hex.substring(4, 6), 16);
    }
    
    return `${r}, ${g}, ${b}`;
} 