Echo Weaver Web Game
====================

This package contains the Echo Weaver web game, a web-based arcade game where you defend a core by creating destructive sound waves.

Quick Start
----------
1. For local development:
   - Run `./run.sh` to start the game server
   - Open your browser and navigate to http://localhost:5000

2. For PythonAnywhere deployment:
   - See DEPLOYMENT_GUIDE.md for detailed instructions

Files and Directories
--------------------
- app.py: Main Flask application
- run.py: Script to run the Flask application
- wsgi.py: WSGI configuration for PythonAnywhere
- requirements.txt: Python dependencies
- templates/: HTML templates
- static/: Static files (JavaScript, CSS, images, sounds)
- highscores/: Directory for storing high scores

Contact
-------
For questions or support, please visit the GitHub repository.

License
-------
This project is licensed under the MIT License. 