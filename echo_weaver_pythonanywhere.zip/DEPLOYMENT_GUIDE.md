# Echo Weaver Deployment Guide for PythonAnywhere

This guide will help you deploy the Echo Weaver game on PythonAnywhere.

## Prerequisites

- A PythonAnywhere account (free tier works fine)
- The `echo_weaver_web.zip` file containing the deployment package

## Deployment Steps

### 1. Upload the Deployment Package

1. Log in to your PythonAnywhere account
2. Go to the Files tab
3. Click "Upload a file" and select the `echo_weaver_web.zip` file
4. Once uploaded, run the following commands in a PythonAnywhere Bash console:
   ```bash
   # Create a directory for your app
   mkdir -p echo_weaver
   
   # Extract the zip file to the directory
   unzip echo_weaver_web.zip -d echo_weaver
   
   # Change to the app directory
   cd echo_weaver
   ```

### 2. Set Up a Virtual Environment

```bash
# Create a virtual environment
mkvirtualenv --python=python3.9 echo_weaver_env

# Activate the virtual environment (should be automatic after creation)
workon echo_weaver_env

# Install the required packages
pip install -r requirements.txt
```

### 3. Configure the Web App

1. Go to the Web tab in PythonAnywhere
2. Click "Add a new web app"
3. Choose your domain name (e.g., yourusername.pythonanywhere.com)
4. Select "Manual configuration"
5. Choose Python 3.9
6. Set the path to your project directory:
   - Source code: `/home/yourusername/echo_weaver`
   - Working directory: `/home/yourusername/echo_weaver`
7. Set the WSGI configuration file path:
   - Click on the WSGI configuration file link
   - Replace the contents with the following (adjust the paths as needed):
   
   ```python
   import sys
   import os
   
   # Add the path to your project directory
   path = '/home/yourusername/echo_weaver'
   if path not in sys.path:
       sys.path.append(path)
   
   # Import your Flask app
   from app import app as application
   
   # Optional: Set environment variables
   os.environ['FLASK_ENV'] = 'production'
   ```
   
8. Save the WSGI file

### 4. Set Up Static Files

1. In the Web tab, scroll down to "Static files"
2. Add the following mappings:
   - URL: `/static/`
   - Directory: `/home/yourusername/echo_weaver/static`

### 5. Start the Web App

1. Click the "Reload" button for your web app
2. Visit your site at `yourusername.pythonanywhere.com`

## Troubleshooting

### If the Game Doesn't Load

1. Check the error logs in the Web tab
2. Ensure all paths in the WSGI file are correct
3. Verify that all required files are in the correct locations
4. Make sure the virtual environment has all required packages installed

### If You See a 500 Error

1. Check the error logs in the Web tab
2. Look for any import errors or file path issues
3. Ensure the `app.py` file is correctly configured

### If Static Files Don't Load

1. Check the static files configuration in the Web tab
2. Ensure the paths are correct
3. Verify that the static files exist in the specified directory

## Updating the Game

To update the game after making changes:

1. Upload the new files to PythonAnywhere
2. Replace the existing files in your app directory
3. Click the "Reload" button for your web app

## Additional Resources

- [PythonAnywhere Help Pages](https://help.pythonanywhere.com/)
- [Flask Deployment Guide](https://flask.palletsprojects.com/en/2.3.x/deploying/)
- [PythonAnywhere Forums](https://www.pythonanywhere.com/forums/) 